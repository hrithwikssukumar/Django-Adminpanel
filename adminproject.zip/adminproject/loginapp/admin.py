from django.contrib import admin
from loginapp.models import CustomUser
# Register your models here.


admin.site.register(CustomUser)